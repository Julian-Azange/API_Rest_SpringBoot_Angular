package com.backendapiRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
