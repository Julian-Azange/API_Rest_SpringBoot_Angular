package com.backendapiRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendApiRestApplication.class, args);
	}

}
